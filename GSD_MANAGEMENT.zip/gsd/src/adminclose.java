
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;

public class adminclose extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		System.out.println("called");
		String status = req.getParameter("status");
		int ticket = Integer.parseInt(req.getParameter("ticket"));
		System.out.println(ticket+status);
		PrintWriter out = res.getWriter();
		Statement stmt = null;
		Connection conn = null;
		try {
			System.out.println("bigining 1");
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("bigining 2");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gsd", "root", "root");
			System.out.println("bigining 3");
			stmt = conn.createStatement();
			System.out.println("inside");
			String sql="UPDATE gsd SET status = 'close' where id='"+ticket+"' ";
			 PreparedStatement pst = (PreparedStatement) conn.prepareStatement(sql);
		    int result=pst.executeUpdate();
		    System.out.println("executeUpdate"+ result);
		     if ( result==1) {
		    	  
		    	 out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.4/sweetalert2.all.js'>"+"</script>");
		    	  out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'>"+"</script>");
		    	  out.println("<script>");
		    	  out.println("$ (document).ready(function(){");
		    	  out.println("swal ( 'Ticket No : "+ticket+" is closed successfully','' , 'success' );");
		    	  out.println("});");
		    	  out.println("</script>");
		           req.getRequestDispatcher("adminhome.jsp").include(req, res); 
		      	
		      } 
		     
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			try {
				if (stmt != null)
					conn.close();
			} catch (SQLException se) {
			}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}

		
				

	}
}
		
	
	
				
