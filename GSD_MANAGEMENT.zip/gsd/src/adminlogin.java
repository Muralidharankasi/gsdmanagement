
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.PreparedStatement;

import java.sql.*;

public class adminlogin extends HttpServlet{
	
public void doPost(HttpServletRequest req,HttpServletResponse res)  
throws ServletException,IOException  
{  
res.setContentType("text/html");
PrintWriter out = res.getWriter();


String adminid = req.getParameter("username");
String password = req.getParameter("password");
Statement stmt = null;
Connection conn = null;
try{

	Class.forName("com.mysql.jdbc.Driver");
	 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gsd", "root", "root");

	 String sql="Select * from admin where adminid=? and password=?";
	 PreparedStatement pst = (PreparedStatement) conn.prepareStatement(sql);
      pst.setString(1, adminid);
      pst.setString(2, password);
      ResultSet rs = pst.executeQuery();
      if (rs.next()) {
    	  

    	  String firstname = rs.getString("firstname");
    	  
    	  System.out.println(firstname);

    	  HttpSession session=req.getSession();  
          session.setAttribute("user",adminid);  
          session.setAttribute("name",firstname);
    	  
    	  System.out.println(session.getAttribute("user").toString()); 
    	  
  		RequestDispatcher rd = req.getRequestDispatcher("adminhome.jsp");
  		rd.forward(req, res);
      	
      } 
      else {
    	  out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.4/sweetalert2.all.js'>"+"</script>");
    	  out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'>"+"</script>");
    	  out.println("<script>");
    	  out.println("$ (document).ready(function(){");
    	  out.println("swal ( 'Oops' ,  'username or password is incorrect',  'error' );");
    	  out.println("});");
    	  out.println("</script>");
           req.getRequestDispatcher("admin.html").include(req, res); 
 
      }
      out.close();  
    
} catch (SQLException se) {
	se.printStackTrace();
} catch (Exception e) {

	e.printStackTrace();
} finally {

	try {
		if (stmt != null)
			conn.close();
	} catch (SQLException se) {
	}
	try {
		if (conn != null)
			conn.close();
	} catch (SQLException se) {
		se.printStackTrace();
	}
}


}
}
