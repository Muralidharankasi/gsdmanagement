
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;

public class adminsignup extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		System.out.println("inside");
		String firstname = req.getParameter("firstname");
		String lastname = req.getParameter("lastname");
		int age = Integer.parseInt(req.getParameter("age"));
		String gender = req.getParameter("gender");
		
		String contactnumber = req.getParameter("contactnumber");
		String adminid = req.getParameter("adminid");
		String password = req.getParameter("password");
		
		System.out.println("inside");
		PrintWriter out = res.getWriter();
		Statement stmt = null;
		Connection conn = null;
		try {
			System.out.println("inside");
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gsd", "root", "root");
			stmt = conn.createStatement();
//			String sql = "insert into profile values ('" + username + "','" + name + "','" + password + "')";
//			stmt.executeUpdate(sql);
			String sql="insert into admin values (?,?,?,?,?,?,?)";
			 PreparedStatement pst = (PreparedStatement) conn.prepareStatement(sql);
		      pst.setString(1, firstname);
		      pst.setString(2, lastname);
		      pst.setInt(3, age);
		      pst.setString(4, gender);
		     
		      pst.setString(5, contactnumber);
		      pst.setString(6, adminid);
		      pst.setString(7, password);
		      System.out.println("inside");
		    int result=pst.executeUpdate();
		     if ( result==1) {
		    	  
		    	 out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.4/sweetalert2.all.js'>"+"</script>");
		    	  out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'>"+"</script>");
		    	  out.println("<script>");
		    	  out.println("$ (document).ready(function(){");
		    	  out.println("swal ( 'You have signed up successfully','' , 'success' );");
		    	  out.println("});");
		    	  out.println("</script>");
		           req.getRequestDispatcher("admin.html").include(req, res); 
		      	
		      } 
		     
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			try {
				if (stmt != null)
					conn.close();
			} catch (SQLException se) {
			}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}



	}
}