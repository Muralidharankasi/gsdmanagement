
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;

public class admintwo extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");

		Statement stmt = null;
		Connection conn = null;
		PrintWriter out = res.getWriter();

		// String user = (String)req.getAttribute("user");
		try {

			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gsd", "root", "root");
			stmt = conn.createStatement();
			ServletContext context = getServletContext();
			String userid = (String) context.getAttribute("userid");
			ResultSet rs = stmt.executeQuery("select * from gsd where status='open'");
			System.out.println(userid);
			String adminname = (String) context.getAttribute("adminname");
			System.out.println("out");
			String open = "open";
			String output = "<table id=\"gsd\">\r\n" + "  <tr>\r\n" + "    <th >Ticket No</th>\r\n"
					+ "    <th>User Id</th>\r\n" + "    <th >Summary</th>\r\n" + "       <th >Created Date</th>\r\n"
					+ "      <th >Status</th>\r\n" + "       <th >Close</th>\r\n" + "  </tr>";
			while (rs.next()) {
				int ticket = rs.getInt("id");
				String user = rs.getString("userid");
				String gsd = rs.getString("gsd");
				String status = rs.getString("status");
				String openingdate = rs.getString("opening_date");
				String closingdate = rs.getString("closing_date");
				String details = rs.getString("details");

				output += "<tr>\r\n" + "    <td>" + ticket + "</td>\r\n" + "    <td>" + user + "</td>\r\n" + "    <td>"
						+ gsd + "</td>\r\n" + "       <td>" + openingdate + "</td>\r\n" + "       <td>" + status
						+ "</td>\r\n" + "       <td>" + "<center><form  action=\"adminclose\"method=\"post\">\r\n"

						+ "<input type=\"text\" name=\"ticket\" value=\"" + ticket + "\"style=\"display:NONE;\">"
						+ "<input type=\"text\" name=\"ticket\" value=\"" + "close" + "\"style=\"display:NONE;\">"
						+ "      <button type=\"submit\" ><b>close</b></button>\r\n" +

						" </form></center>";

			}
			output += "<table>";

			out.println(output);

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			try {
				if (stmt != null)
					conn.close();
			} catch (SQLException se) {
			}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}

	}

}