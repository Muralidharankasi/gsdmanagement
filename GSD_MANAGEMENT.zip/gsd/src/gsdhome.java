
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;

public class gsdhome extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		System.out.println("called");
		
		String gsd = req.getParameter("gsd");
		String details = req.getParameter("details");
		
		ServletContext context=getServletContext();  
		String userid=(String)context.getAttribute("userid"); 
		
		
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
		Date date = new Date();
	String openingdate=formatter.format(date);
		
		String status="open";
		
		PrintWriter out = res.getWriter();
		Statement stmt = null;
		Connection conn = null;
		try {
			System.out.println("bigining 1");
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("bigining 2");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gsd", "root", "root");
			System.out.println("bigining 3");
			stmt = conn.createStatement();
			System.out.println("inside");
			String sql="insert into gsd(userid,gsd,status,opening_date,details) values (?,?,?,?,?)";
			 PreparedStatement pst = (PreparedStatement) conn.prepareStatement(sql);
		      pst.setString(1, userid);
		      pst.setString(2, gsd);
		      pst.setString(3, status);
		      pst.setString(4, openingdate);
		      pst.setString(5, details);
		      System.out.println("end");
		    int result=pst.executeUpdate();
		    System.out.println("executeUpdate");
		     if ( result==1) {
		    	  
		    	 out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.4/sweetalert2.all.js'>"+"</script>");
		    	  out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'>"+"</script>");
		    	  out.println("<script>");
		    	  out.println("$ (document).ready(function(){");
		    	  out.println("swal ( 'GSD Ticket Raised Successfully','' , 'success' );");
		    	  out.println("});");
		    	  out.println("</script>");
		           req.getRequestDispatcher("gsdhome.jsp").include(req, res); 
		      	
		      } 
		     
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			try {
				if (stmt != null)
					conn.close();
			} catch (SQLException se) {
			}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}

		
				

	}
}