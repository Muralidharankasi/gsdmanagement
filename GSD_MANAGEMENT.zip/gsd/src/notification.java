
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;


public class notification extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");

		Statement stmt = null;
		Connection conn = null;
		PrintWriter out = res.getWriter();
		
		// String user = (String)req.getAttribute("user");
		try {

			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gsd", "root", "root");
			stmt = conn.createStatement();
			ServletContext context=getServletContext();  
			String userid=(String)context.getAttribute("userid"); 
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
			Date date = new Date();
		String opening=formatter.format(date);
		
		
			ResultSet rs = stmt.executeQuery("select * from gsd where status='open'and userid='"+userid+"'");
			System.out.println(userid);
			
			System.out.println("out");
			String open="open";
			
			String output="";	
			
			while (rs.next()) {
		int ticket=rs.getInt("id");
				String user = rs.getString("userid");
				String gsd = rs.getString("gsd");
				String status = rs.getString("status");
				String openingdate = rs.getString("opening_date");
				String closingdate = rs.getString("closing_date");
				String details = rs.getString("details");

	output+="<div class=\"alert success\">\r\n" + 
			"   <center>\r\n" + 
			"  <strong>Ticket No&nbsp;&nbsp;:&nbsp;&nbsp;</strong> "
			+ ticket
			+ " <br><br>\r\n" + 
			"  <strong>Summary&nbsp;&nbsp;:&nbsp;&nbsp;</strong> "
			+ gsd
			+ "<br><br>\r\n" + 
			"  <strong>Status&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;</strong> "
			+ status
			+ "\r\n" + 
			"  \r\n" + 
			"  </center>\r\n" + 
			"</div>";	

			
			

			}
			
			out.println(output);

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			try {
				if (stmt != null)
					conn.close();
			} catch (SQLException se) {
			}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
			
	}
	
}