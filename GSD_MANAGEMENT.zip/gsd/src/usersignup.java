
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;

public class usersignup extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		System.out.println("called");
	
		String firstname = req.getParameter("firstname");
		String lastname = req.getParameter("lastname");
		int age =Integer.parseInt(req.getParameter("age"));
		String gender = req.getParameter("gender");
		String address = req.getParameter("address");
		String city = req.getParameter("city");
		String zipcode = req.getParameter("zipcode");
		String contactnumber =req.getParameter("contactnumber");
		String userid = req.getParameter("userid");
		String password = req.getParameter("password");
		System.out.println("dfhgfgd");
		
		PrintWriter out = res.getWriter();
		Statement stmt = null;
		Connection conn = null;
		try {
			System.out.println("bigining 1");
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("bigining 2");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gsd", "root", "root");
			System.out.println("bigining 3");
			stmt = conn.createStatement();
			System.out.println("inside");
			String sql="insert into user values (?,?,?,?,?,?,?,?,?,?)";
			 PreparedStatement pst = (PreparedStatement) conn.prepareStatement(sql);
		      pst.setString(1, firstname);
		      pst.setString(2, lastname);
		      pst.setInt(3, age);
		      
		      pst.setString(4, gender);
		      pst.setString(5, address);
		      pst.setString(6, city);
		      pst.setString(7, zipcode);
		      pst.setString(8, contactnumber);
		      pst.setString(9, userid);
		      pst.setString(10, password);
		      System.out.println("end");
		     
		      
		    int result=pst.executeUpdate();
		    
		    System.out.println("executeUpdate");
		     if ( result==1) {
		    	  
		    	 out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.4/sweetalert2.all.js'>"+"</script>");
		    	  out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'>"+"</script>");
		    	  out.println("<script>");
		    	  out.println("$ (document).ready(function(){");
		    	  out.println("swal ( 'You have signed up successfully','' , 'success' );");
		    	  out.println("});");
		    	  out.println("</script>");
		           req.getRequestDispatcher("index.html").include(req, res); 
		      	
		      } 
		     
		} catch (SQLException se) {
			    	  out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.4/sweetalert2.all.js'>"+"</script>");
			    	  out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'>"+"</script>");
			    	  out.println("<script>");
			    	  out.println("$ (document).ready(function(){");
			    	  out.println("swal ( 'Oops' ,  'Username already exist',  'error' );");
			    	  out.println("});");
			    	  out.println("</script>");
			    	  req.getRequestDispatcher("user signup.html").include(req, res); 
			      	
			      
			se.printStackTrace();
		} catch (Exception e) {
			
			e.printStackTrace();
		} finally {

			try {
				if (stmt != null)
					conn.close();
			} catch (SQLException se) {
				
		
			}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
				
			}
		}

		
				

	}
}